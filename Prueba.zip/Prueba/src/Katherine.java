
import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Eliana Velasquez
 */
public class Katherine {
    int x;
    int y;
    JPanel MiJP;
    
    Katherine (JPanel Mij){
        this.x=0;
        this.y=0;
        this.MiJP=Mij;
        
    }
    /**
     * Este metodo nos va a permitir ubicar la imagen dentro del lienzo
     * @param g
     * @param xi
     * @param yi
     * @param Direccion 
     */
    
    public void DibujarK (Graphics g,int xi, int yi,String Direccion){
        this.x=xi;
        this.y=yi;
        this.MiJP.update(g);
        ImageIcon MiImagen= new ImageIcon (Direccion);
        g.drawImage(MiImagen.getImage(), xi, yi, MiJP);
    }
    
    public int Coordx (){
        return this.x;
    }
    
    public int Coordy(){
        return this.y;
    }
}
